#!/usr/bin/env python3
# Chain of thought:
"""Reproducible Warsaw apartment sale/rent price regression experiment."""

from __future__ import annotations

# PYTHONHASHSEED is read when the interpreter starts. Re-exec once so that
# setting it here actually affects hash randomization in this process.
import os
import sys

if os.environ.get("PYTHONHASHSEED") != "42":
    _environment = os.environ.copy()
    _environment["PYTHONHASHSEED"] = "42"
    _environment.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    os.execvpe(sys.executable, [sys.executable, *sys.argv], _environment)

# Must be set before importing/initializing PyTorch CUDA support.
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

import argparse
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd
import torch
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.compose import TransformedTargetRegressor
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


RANDOM_STATE = 42
TARGET_COLUMN = "price"
FEATURE_COLUMNS: tuple[str, ...] = (
    "squareMeters",
    "rooms",
    "floor",
    "buildYear",
    "latitude",
    "longitude",
    "centreDistance",
    "poiCount",
    "hasParkingSpace",
    "hasBalcony",
    "hasElevator",
    "hasSecurity",
    "hasStorageRoom",
)
AMENITY_COLUMNS: tuple[str, ...] = FEATURE_COLUMNS[8:]


@dataclass(frozen=True)
class LoadedDataset:
    """Clean Warsaw records and counts from the source CSV."""

    frame: pd.DataFrame
    source_rows: int
    warsaw_rows: int
    usable_rows: int


@dataclass(frozen=True)
class PreparedSplits:
    """Shared, leakage-safe train/validation/test arrays."""

    X_train: np.ndarray
    X_validation: np.ndarray
    X_test: np.ndarray
    y_train: np.ndarray
    y_validation: np.ndarray
    y_test: np.ndarray
    partition_sizes: dict[str, int]


class ApartmentMLP(nn.Module):
    """The required 13-64-32-1 feed-forward regression network."""

    def __init__(self) -> None:
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(13, 64),
            nn.ReLU(),
            nn.Dropout(p=0.2),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Dropout(p=0.2),
            nn.Linear(32, 1),
        )

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return self.network(features).squeeze(-1)


def set_global_seed(seed: int = RANDOM_STATE) -> None:
    """Seed Python, NumPy and PyTorch and request deterministic operations."""
    os.environ["PYTHONHASHSEED"] = str(seed)
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    torch.use_deterministic_algorithms(True)
    if hasattr(torch.backends, "cudnn"):
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.allow_tf32 = False
    if hasattr(torch.backends, "cuda") and hasattr(torch.backends.cuda, "matmul"):
        torch.backends.cuda.matmul.allow_tf32 = False


def _is_missing(value: Any) -> bool:
    """Return True for scalar pandas/NumPy missing values."""
    try:
        missing = pd.isna(value)
    except (TypeError, ValueError):
        return False
    return bool(missing) if isinstance(missing, (bool, np.bool_)) else False


def _convert_amenity_value(value: Any, column: str, row_index: Any) -> float:
    """Map known boolean-like amenity values to 0.0/1.0; preserve missing."""
    if _is_missing(value):
        return float("nan")

    if isinstance(value, (bool, np.bool_)):
        return 1.0 if bool(value) else 0.0

    if isinstance(value, str):
        token = value.strip().casefold()
        if token in {"", "na", "n/a", "nan", "null", "none"}:
            return float("nan")
        if token in {"true", "yes"}:
            return 1.0
        if token in {"false", "no"}:
            return 0.0
        try:
            numeric_value = float(token)
        except ValueError:
            numeric_value = float("nan")
    elif isinstance(value, (int, float, np.integer, np.floating)):
        numeric_value = float(value)
    else:
        numeric_value = float("nan")

    if numeric_value == 1.0:
        return 1.0
    if numeric_value == 0.0:
        return 0.0

    raise ValueError(
        f"Unknown amenity value {value!r} in column {column!r} at CSV row "
        f"index {row_index!r}. Accepted values are True/False, yes/no, "
        "1/0, or missing values. Correct the source data rather than "
        "assigning an arbitrary meaning."
    )


def load_data(csv_path: Path) -> LoadedDataset:
    """Read one CSV, retain Warsaw, and normalize target and predictors."""
    if not csv_path.is_file():
        raise FileNotFoundError(f"CSV file does not exist: {csv_path}")

    try:
        source = pd.read_csv(csv_path, low_memory=False)
    except (OSError, pd.errors.ParserError, UnicodeDecodeError) as exc:
        raise ValueError(f"Could not read CSV file {csv_path}: {exc}") from exc

    required_columns = ["city", TARGET_COLUMN, *FEATURE_COLUMNS]
    missing_columns = [
        column for column in required_columns if column not in source.columns
    ]
    if missing_columns:
        raise ValueError(
            f"{csv_path} is missing required columns: {missing_columns}. "
            f"Required columns are: {required_columns}"
        )

    source_rows = int(len(source))
    city_values = source["city"].astype("string").str.strip().str.casefold()
    warsaw_mask = city_values.eq("warszawa").fillna(False)
    warsaw = source.loc[warsaw_mask, required_columns].copy()
    warsaw_rows = int(len(warsaw))

    if warsaw.empty:
        raise ValueError(
            "No rows with city == 'warszawa' (case-insensitive) "
            f"were found in {csv_path}."
        )

    numeric_target = pd.to_numeric(warsaw[TARGET_COLUMN], errors="coerce")
    target_values = numeric_target.to_numpy(dtype=np.float64, na_value=np.nan)
    valid_target_mask = np.isfinite(target_values)
    usable = warsaw.loc[valid_target_mask].copy()
    usable[TARGET_COLUMN] = target_values[valid_target_mask]

    if usable.empty:
        raise ValueError(
            f"The Warsaw subset in {csv_path} contains no finite numeric target prices."
        )

    for column in FEATURE_COLUMNS:
        if column in AMENITY_COLUMNS:
            converted = [
                _convert_amenity_value(value, column, row_index)
                for row_index, value in usable[column].items()
            ]
            values = np.asarray(converted, dtype=np.float64)
        else:
            numeric_values = pd.to_numeric(usable[column], errors="coerce")
            values = numeric_values.to_numpy(dtype=np.float64, na_value=np.nan)
            values[~np.isfinite(values)] = np.nan
        usable[column] = values

    # Keep exactly the requested feature order plus the target. All metadata,
    # including city/id/type/ownership/condition, is deliberately discarded.
    cleaned = usable.loc[:, [*FEATURE_COLUMNS, TARGET_COLUMN]].reset_index(drop=True)
    return LoadedDataset(
        frame=cleaned,
        source_rows=source_rows,
        warsaw_rows=warsaw_rows,
        usable_rows=int(len(cleaned)),
    )


def preprocess_splits(frame: pd.DataFrame) -> PreparedSplits:
    """Create shared 70/15/15 splits and fit imputer/scaler on train only."""
    if len(frame) < 7:
        raise ValueError(
            "At least 7 valid Warsaw rows are required to create non-empty "
            "70/15/15 partitions and calculate test R²."
        )

    X = frame.loc[:, FEATURE_COLUMNS].to_numpy(dtype=np.float64)
    y = frame[TARGET_COLUMN].to_numpy(dtype=np.float64)
    if not np.isfinite(y).all():
        raise ValueError("Target prices contain non-finite values after data cleaning.")

    all_indices = np.arange(len(frame))
    train_indices, holdout_indices = train_test_split(
        all_indices,
        test_size=0.30,
        random_state=RANDOM_STATE,
    )
    validation_indices, test_indices = train_test_split(
        holdout_indices,
        test_size=0.50,
        random_state=RANDOM_STATE,
    )

    X_train_raw = X[train_indices]
    X_validation_raw = X[validation_indices]
    X_test_raw = X[test_indices]

    # A median cannot be learned for a feature that is wholly missing in the
    # training set. Fail rather than silently inventing a replacement value.
    empty_training_features = [
        FEATURE_COLUMNS[index]
        for index in range(X_train_raw.shape[1])
        if np.isnan(X_train_raw[:, index]).all()
    ]
    if empty_training_features:
        raise ValueError(
            "These predictors are entirely missing in the training partition, "
            "so a training median cannot be fitted: "
            f"{empty_training_features}"
        )

    imputer = SimpleImputer(strategy="median", keep_empty_features=True)
    X_train_imputed = imputer.fit_transform(X_train_raw)
    X_validation_imputed = imputer.transform(X_validation_raw)
    X_test_imputed = imputer.transform(X_test_raw)

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_imputed)
    X_validation_scaled = scaler.transform(X_validation_imputed)
    X_test_scaled = scaler.transform(X_test_imputed)

    for split_name, array in (
        ("training", X_train_scaled),
        ("validation", X_validation_scaled),
        ("testing", X_test_scaled),
    ):
        if array.shape[1] != len(FEATURE_COLUMNS):
            raise RuntimeError(
                f"{split_name.capitalize()} predictors have {array.shape[1]} "
                f"columns; expected {len(FEATURE_COLUMNS)}."
            )
        if not np.isfinite(array).all():
            raise ValueError(
                f"Non-finite predictor values remain in the {split_name} split "
                "after imputation and scaling."
            )

    return PreparedSplits(
        X_train=np.asarray(X_train_scaled, dtype=np.float64),
        X_validation=np.asarray(X_validation_scaled, dtype=np.float64),
        X_test=np.asarray(X_test_scaled, dtype=np.float64),
        y_train=y[train_indices],
        y_validation=y[validation_indices],
        y_test=y[test_indices],
        partition_sizes={
            "train": int(len(train_indices)),
            "validation": int(len(validation_indices)),
            "test": int(len(test_indices)),
        },
    )


def train_mlp(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_validation: np.ndarray,
    y_validation: np.ndarray,
) -> tuple[ApartmentMLP, dict[str, int | float]]:
    """Train the required MLP with validation-MSE early stopping."""
    set_global_seed(RANDOM_STATE)

    X_train_32 = np.asarray(X_train, dtype=np.float32)
    X_validation_32 = np.asarray(X_validation, dtype=np.float32)
    y_train_32 = np.asarray(y_train, dtype=np.float32)
    y_validation_32 = np.asarray(y_validation, dtype=np.float32)

    for name, values in (
        ("X_train", X_train_32),
        ("X_validation", X_validation_32),
        ("y_train", y_train_32),
        ("y_validation", y_validation_32),
    ):
        if not np.isfinite(values).all():
            raise ValueError(
                f"{name} cannot be represented as finite float32 values for PyTorch."
            )

    train_dataset = TensorDataset(
        torch.from_numpy(X_train_32),
        torch.from_numpy(y_train_32),
    )
    loader_generator = torch.Generator(device="cpu")
    loader_generator.manual_seed(RANDOM_STATE)
    train_loader = DataLoader(
        train_dataset,
        batch_size=64,
        shuffle=True,
        num_workers=0,
        generator=loader_generator,
        drop_last=False,
    )

    model = ApartmentMLP()
    loss_function = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    validation_features = torch.from_numpy(X_validation_32)
    validation_targets = torch.from_numpy(y_validation_32)
    best_validation_mse = float("inf")
    best_state: dict[str, torch.Tensor] | None = None
    best_epoch = 0
    epochs_without_improvement = 0
    epochs_trained = 0

    for epoch in range(1, 501):
        model.train()
        for batch_features, batch_targets in train_loader:
            optimizer.zero_grad(set_to_none=True)
            predictions = model(batch_features)
            loss = loss_function(predictions, batch_targets)
            if not torch.isfinite(loss):
                raise FloatingPointError(
                    f"MLP training loss became non-finite at epoch {epoch}."
                )
            loss.backward()
            optimizer.step()

        model.eval()
        with torch.no_grad():
            validation_predictions = model(validation_features)
            validation_mse_tensor = loss_function(
                validation_predictions,
                validation_targets,
            )

        validation_mse = float(validation_mse_tensor.item())
        if not np.isfinite(validation_mse):
            raise FloatingPointError(
                f"MLP validation MSE became non-finite at epoch {epoch}."
            )

        epochs_trained = epoch
        if validation_mse < best_validation_mse:
            best_validation_mse = validation_mse
            best_epoch = epoch
            best_state = {
                name: tensor.detach().cpu().clone()
                for name, tensor in model.state_dict().items()
            }
            epochs_without_improvement = 0
        else:
            epochs_without_improvement += 1

        if epochs_without_improvement >= 20:
            break

    if best_state is None:
        raise RuntimeError("MLP training ended without a valid validation checkpoint.")

    model.load_state_dict(best_state)
    model.eval()
    metadata: dict[str, int | float] = {
        "best_epoch": best_epoch,
        "epochs_trained": epochs_trained,
        "best_validation_mse": best_validation_mse,
        "early_stopping_patience": 20,
        "maximum_epochs": 500,
    }
    return model, metadata


def predict_mlp(model: ApartmentMLP, X: np.ndarray) -> np.ndarray:
    """Return MLP predictions as a one-dimensional NumPy array."""
    model.eval()
    features = torch.as_tensor(np.asarray(X, dtype=np.float32))
    with torch.no_grad():
        predictions = model(features).cpu().numpy().astype(np.float64, copy=False)
    return predictions.reshape(-1)


def train_svr(
    X_train: np.ndarray,
    y_train: np.ndarray,
) -> TransformedTargetRegressor:
    """Fit RBF SVR with training-only target standardization."""
    svr = TransformedTargetRegressor(
        regressor=SVR(kernel="rbf", C=10.0, epsilon=0.1, gamma="scale"),
        transformer=StandardScaler(),
    )
    svr.fit(X_train, y_train)
    return svr


def train_random_forest(
    X_train: np.ndarray,
    y_train: np.ndarray,
) -> RandomForestRegressor:
    """Fit the specified reproducible random forest regressor."""
    model = RandomForestRegressor(
        n_estimators=300,
        random_state=RANDOM_STATE,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)
    return model


def evaluate_model(y_true: np.ndarray, predictions: np.ndarray) -> dict[str, float]:
    """Validate predictions and compute original-scale regression metrics."""
    actual = np.asarray(y_true, dtype=np.float64).reshape(-1)
    predicted = np.asarray(predictions, dtype=np.float64).reshape(-1)

    if actual.size == 0:
        raise ValueError("Cannot evaluate a model on an empty test partition.")
    if actual.shape != predicted.shape:
        raise ValueError(
            f"Prediction length {predicted.size} does not match test target "
            f"length {actual.size}."
        )
    if not np.isfinite(actual).all():
        raise ValueError("Test targets contain non-finite values.")
    if not np.isfinite(predicted).all():
        invalid_count = int((~np.isfinite(predicted)).sum())
        raise FloatingPointError(
            f"Model produced {invalid_count} non-finite test prediction(s)."
        )
    if actual.size < 2:
        raise ValueError("At least two test observations are required to calculate R².")

    metrics = {
        "MAE": float(mean_absolute_error(actual, predicted)),
        "RMSE": float(np.sqrt(mean_squared_error(actual, predicted))),
        "R2": float(r2_score(actual, predicted)),
    }
    if not all(np.isfinite(value) for value in metrics.values()):
        raise FloatingPointError(f"Evaluation produced non-finite metrics: {metrics}")
    return metrics


def _fit_and_evaluate(
    *,
    task_name: str,
    model_name: str,
    fit_function: Callable[[np.ndarray, np.ndarray], Any],
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_test: np.ndarray,
    y_test: np.ndarray,
) -> tuple[dict[str, float], Any]:
    """Fit a scikit-learn estimator and evaluate only on the test partition."""
    try:
        model = fit_function(X_train, y_train)
        predictions = model.predict(X_test)
        return evaluate_model(y_test, predictions), model
    except Exception as exc:
        raise RuntimeError(f"{task_name}: {model_name} failed: {exc}") from exc


def run_experiment(task_name: str, csv_path: Path) -> dict[str, Any]:
    """Run one complete sale or rent experiment and return JSON-ready results."""
    loaded = load_data(csv_path)
    splits = preprocess_splits(loaded.frame)

    print(f"\n{'=' * 72}")
    print(f"TASK: {task_name.upper()}")
    print(f"Source file: {csv_path}")
    print(
        "Rows: "
        f"source={loaded.source_rows:,}, "
        f"Warsaw={loaded.warsaw_rows:,}, "
        f"finite-price Warsaw={loaded.usable_rows:,}"
    )
    print(
        "Partitions: "
        f"train={splits.partition_sizes['train']:,} "
        f"({splits.partition_sizes['train'] / loaded.usable_rows:.1%}), "
        f"validation={splits.partition_sizes['validation']:,} "
        f"({splits.partition_sizes['validation'] / loaded.usable_rows:.1%}), "
        f"test={splits.partition_sizes['test']:,} "
        f"({splits.partition_sizes['test'] / loaded.usable_rows:.1%})"
    )

    metrics: dict[str, dict[str, float]] = {}
    training_details: dict[str, Any] = {}

    try:
        mlp_model, mlp_details = train_mlp(
            splits.X_train,
            splits.y_train,
            splits.X_validation,
            splits.y_validation,
        )
        mlp_predictions = predict_mlp(mlp_model, splits.X_test)
        metrics["MLP"] = evaluate_model(splits.y_test, mlp_predictions)
        training_details["MLP"] = mlp_details
    except Exception as exc:
        raise RuntimeError(f"{task_name}: MLP failed: {exc}") from exc

    metrics["SVR (RBF)"], _ = _fit_and_evaluate(
        task_name=task_name,
        model_name="SVR (RBF)",
        fit_function=train_svr,
        X_train=splits.X_train,
        y_train=splits.y_train,
        X_test=splits.X_test,
        y_test=splits.y_test,
    )

    metrics["Random Forest"], _ = _fit_and_evaluate(
        task_name=task_name,
        model_name="Random Forest",
        fit_function=train_random_forest,
        X_train=splits.X_train,
        y_train=splits.y_train,
        X_test=splits.X_test,
        y_test=splits.y_test,
    )

    training_median = float(np.median(splits.y_train))
    baseline_predictions = np.full(
        shape=len(splits.y_test),
        fill_value=training_median,
        dtype=np.float64,
    )
    metrics["Training-set median baseline"] = evaluate_model(
        splits.y_test,
        baseline_predictions,
    )

    print("\nTest-set metrics (original price scale)")
    print(f"{'Model':32s} {'MAE':>14s} {'RMSE':>14s} {'R²':>12s}")
    print("-" * 76)
    for model_name, model_metrics in metrics.items():
        print(
            f"{model_name:32s} "
            f"{model_metrics['MAE']:14,.4f} "
            f"{model_metrics['RMSE']:14,.4f} "
            f"{model_metrics['R2']:12.6f}"
        )
    print(
        f"MLP early stopping: best epoch={mlp_details['best_epoch']}, "
        f"epochs trained={mlp_details['epochs_trained']}"
    )

    return {
        "source_file": str(csv_path),
        "row_counts": {
            "source_rows": loaded.source_rows,
            "warsaw_rows": loaded.warsaw_rows,
            "usable_warsaw_rows_with_finite_price": loaded.usable_rows,
        },
        "partition_sizes": splits.partition_sizes,
        "training_details": training_details,
        "training_set_median_price": training_median,
        "metrics": metrics,
    }


def parse_arguments() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description=(
            "Train and compare MLP, RBF-SVR, Random Forest and a median "
            "baseline for Warsaw apartment sale and rent prices."
        )
    )
    parser.add_argument(
        "--sale_data",
        type=Path,
        default=Path("apartments_pl_2024_06.csv"),
        help="Path to the June 2024 apartment sale CSV.",
    )
    parser.add_argument(
        "--rent_data",
        type=Path,
        default=Path("apartments_rent_pl_2024_06.csv"),
        help="Path to the June 2024 apartment rent CSV.",
    )
    parser.add_argument(
        "--out_dir",
        type=Path,
        default=Path("outputs"),
        help="Directory in which evaluation_metrics.json will be saved.",
    )
    return parser.parse_args()


def main() -> None:
    """Run both tasks and serialize all evaluation results to JSON."""
    args = parse_arguments()
    set_global_seed(RANDOM_STATE)

    sale_results = run_experiment("sale", args.sale_data)
    rent_results = run_experiment("rent", args.rent_data)

    output = {
        "experiment": {
            "dataset": "Apartment Prices in Poland — June 2024",
            "source": (
                "https://www.kaggle.com/datasets/krzysztofjamroz/"
                "apartment-prices-in-poland"
            ),
            "random_state": RANDOM_STATE,
            "target_column": TARGET_COLUMN,
            "target_scale": "original; no logarithmic or power transformation",
            "feature_columns_in_model_order": list(FEATURE_COLUMNS),
            "split_ratios": {
                "train": 0.70,
                "validation": 0.15,
                "test": 0.15,
            },
            "preprocessing": {
                "imputer": (
                    "SimpleImputer(strategy='median'), "
                    "fitted on training predictors only"
                ),
                "scaler": (
                    "StandardScaler, fitted on imputed training predictors only"
                ),
                "svr_target_transform": (
                    "StandardScaler fitted on training targets only; "
                    "predictions inverse-transformed"
                ),
            },
        },
        "tasks": {
            "sale": sale_results,
            "rent": rent_results,
        },
    }

    args.out_dir.mkdir(parents=True, exist_ok=True)
    output_path = args.out_dir / "evaluation_metrics.json"
    temporary_path = output_path.with_suffix(".json.tmp")
    try:
        with temporary_path.open("w", encoding="utf-8") as output_file:
            json.dump(
                output,
                output_file,
                indent=2,
                ensure_ascii=False,
                allow_nan=False,
            )
            output_file.write("\n")
        temporary_path.replace(output_path)
    except OSError as exc:
        raise OSError(
            f"Could not write evaluation results to {output_path}: {exc}"
        ) from exc

    print(f"\nSaved evaluation results to: {output_path.resolve()}")


if __name__ == "__main__":
    try:
        main()
    except (FileNotFoundError, ValueError, RuntimeError, OSError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1) from error
